// This file holds the main code for plugins. Code in this file has access to
// the *figma document* via the figma global object.
// You can access browser APIs in the <script> tag inside "ui.html" which has a
// full browser environment (See https://www.figma.com/plugin-docs/how-plugins-run).

// This plugin creates rectangles on the screen.
const nodes: SceneNode[] = [];

// Import both components
Promise.all([
  figma.importComponentByKeyAsync('7473bc6b250a6792153b4482619b27b03b8f2bb8'), // Hotspot
  figma.importComponentByKeyAsync('4accb572e7d08cd3d67d459e831a3eb4a536d66d') // Replace with actual text alternatives annotation component key
])
.then(([hotspotComponent, annotationComponent]) => {
  // Once we have the components, create instances for each selected node
  figma.currentPage.selection.forEach(node => {
    // Create Hotspot instance
    const hotspotInstance = hotspotComponent.createInstance();
    const absoluteBoundingBox = node.absoluteBoundingBox;
    
    if (absoluteBoundingBox) {
      hotspotInstance.x = absoluteBoundingBox.x;
      hotspotInstance.y = absoluteBoundingBox.y;
      hotspotInstance.resize(node.width, node.height);
      hotspotInstance.name = "Focusable area";

      // Create Annotation instance
      const annotationInstance = annotationComponent.createInstance();
      annotationInstance.name = "Annotation";
      
      // Append both instances to the page (they must have a parent before grouping)
      figma.currentPage.appendChild(hotspotInstance);
      figma.currentPage.appendChild(annotationInstance);

      // Position annotation above hotspot so that it is centered horizontally and its bottom touches the top of the hotspot
      annotationInstance.x = hotspotInstance.x + (hotspotInstance.width - annotationInstance.width) / 2;
      annotationInstance.y = hotspotInstance.y - annotationInstance.height;

      // Group the hotspots with annotations and rename the group accordingly
      const group = figma.group([hotspotInstance, annotationInstance], figma.currentPage);
      group.name = "Text alternatives for images group";
      
      // Add the group to the nodes array instead of the individual instances
      nodes.push(group);
    }
  });

  // Update selection and viewport
  figma.currentPage.selection = nodes;
  figma.viewport.scrollAndZoomIntoView(nodes);
  
  // Close the plugin
  figma.closePlugin();
})
.catch(error => {
  // Handle any errors (e.g., component not found)
  figma.notify(`Error: ${error.message}`);
  figma.closePlugin();
});
